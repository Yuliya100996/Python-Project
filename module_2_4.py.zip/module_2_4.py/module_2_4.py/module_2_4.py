numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
primes = []
not_primes = []
for i in numbers:
    if i == 1:
        continue
    is_praim = True
    for j in range(2, i):
        if i % j == 0:
            is_praim = False
            break
    if is_praim:
        primes.append(i)
    else:
        not_primes.append(i)
print('Primes:', primes)
print('Not primes:', not_primes)