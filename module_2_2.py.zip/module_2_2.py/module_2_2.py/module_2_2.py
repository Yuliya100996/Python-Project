first = 9
second = 15
third = 9
if first == second == third:
    print(3)
elif first == second or second == third or first == third:
    print(2)
else:
    print(0)

first = 7
second = 15
third = 9
if first == second == third:
    print(3)
elif first == second or second == third or first == third:
    print(2)
else:
    print(0)
