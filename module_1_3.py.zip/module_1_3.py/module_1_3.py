name = 'Yuliya'
print(name)
age = 27
print(age)
new_age = 28
print(new_age)
is_student = age < new_age
print(is_student)
print('Name:', name)
print('Age:', age)
print('New age:', new_age)
print('Is student:', is_student)
