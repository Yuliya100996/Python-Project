name = 'Yuliya'
print(name)
age = 27
print(age)
new_age = 28
print(new_age)
is_student = age < new_age
print(is_student)
print('Name:', name, ',', 'Age:', age, ',', 'New age:', new_age, ',', 'Is student:', is_student)
