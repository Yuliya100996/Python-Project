name = 'Yuliya'
print(name)
age = 27
print(age)
age = age + 1
print (age)
is_student = True
print(is_student)
print('Name:', name)
print('Age:', age)
print('New age:', (age - 1))
print('Is student:', is_student)

