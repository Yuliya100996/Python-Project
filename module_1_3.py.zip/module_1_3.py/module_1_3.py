name = 'Yuliya'
print(name)
age = 27
print(age)
age = age + 1
print(age)
is_student = True
print(is_student)
print('Name:', name)
print('Age:', age - 1)
print('New age:', (age))
print('Is student:', is_student)
